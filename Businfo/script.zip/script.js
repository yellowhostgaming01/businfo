// let currentEdit = null; // To keep track of the current song being edited

// function renderTable() {
//   const tbody = document.getElementById('musicTable').querySelector('tbody');
//   tbody.innerHTML = '';

//   // Sort categories alphabetically
//   const sortedCategories = Object.keys(audiourls).sort();

//   sortedCategories.forEach(category => {
//     // Replace spaces with hyphens and capitalize the first letter
//     const formattedCategory = category.replace(/\s+/g, '-').charAt(0).toUpperCase() + category.replace(/\s+/g, '-').slice(1);

//     if (audiourls[category].length === 0) {
//       const row = document.createElement('tr');

//       const categoryCell = document.createElement('td');
//       categoryCell.textContent = formattedCategory;
//       row.appendChild(categoryCell);

//       const nameCell = document.createElement('td');
//       nameCell.textContent = '!Available';
//       row.appendChild(nameCell);

//       const urlCell = document.createElement('td');
//       urlCell.textContent = '!Available';
//       row.appendChild(urlCell);

//       const actionsCell = document.createElement('td');
//       const editIcon = document.createElement('span');
//       editIcon.textContent = '✏️'; // Unicode for pencil
//       editIcon.classList.add('icon');
//       editIcon.addEventListener('click', () => {
//         document.getElementById('editFormContainer').style.display = 'block';
//         editSong(category, 0); // For empty categories, we use index 0
//       });

//       const removeIcon = document.createElement('span');
//       removeIcon.textContent = '❌'; // Unicode for cross
//       removeIcon.classList.add('icon');
//       removeIcon.addEventListener('click', () => {
//         confirm('Are you sure you want to delete this entry?').then(result => {
//           if (result) {
//             removeSong(category, 0); // For empty categories, we use index 0
//           }
//         });
//       });

//       actionsCell.appendChild(editIcon);
//       actionsCell.appendChild(removeIcon);
//       actionsCell.classList.add('actions');
//       row.appendChild(actionsCell);

//       tbody.appendChild(row);
//     } else {
//       audiourls[category].forEach((song, index) => {
//         const row = document.createElement('tr');

//         const categoryCell = document.createElement('td');
//         categoryCell.textContent = formattedCategory;
//         row.appendChild(categoryCell);

//         const nameCell = document.createElement('td');
//         nameCell.textContent = song.Name || '-';
//         row.appendChild(nameCell);

//         const urlCell = document.createElement('td');
//         urlCell.textContent = song.url || '-';
//         row.appendChild(urlCell);

//         const actionsCell = document.createElement('td');
//         const editIcon = document.createElement('span');
//         editIcon.textContent = '✏️'; // Unicode for pencil
//         editIcon.classList.add('icon');
//         editIcon.addEventListener('click', () => {
//           document.getElementById('editFormContainer').style.display = 'block';
//           editSong(category, index);
//         });

//         const removeIcon = document.createElement('span');
//         removeIcon.textContent = '❌'; // Unicode for cross
//         removeIcon.classList.add('icon');
//         removeIcon.addEventListener('click', () => {
//           confirm('Are you sure you want to delete this entry?').then(result => {
//             if (result) {
//               removeSong(category, index);
//             }
//           });
//         });

//         actionsCell.appendChild(editIcon);
//         actionsCell.appendChild(removeIcon);
//         actionsCell.classList.add('actions');
//         row.appendChild(actionsCell);

//         tbody.appendChild(row);
//       });
//     }
//   });
// }

// function editSong(category, index) {
//   const song = audiourls[category][index];
//   document.getElementById('category').value = category;
//   document.getElementById('name').value = song.Name || '';
//   document.getElementById('url').value = song.url || '';

//   // Keep track of the current song being edited
//   currentEdit = { oldCategory: category, index };
// }

// function removeSong(category, index) {
//   audiourls[category].splice(index, 1);
//   if (audiourls[category].length === 0) {
//     delete audiourls[category];
//   }
//   renderTable();
// }

// document.getElementById('pushDataButton').addEventListener('click', function() {
//   const category = document.getElementById('category').value;
//   const name = document.getElementById('name').value;
//   const url = document.getElementById('url').value;

//   if (category && name && url) {
//     if (currentEdit) {
//       // Update existing song
//       const { oldCategory, index } = currentEdit;
//       // Remove song from old category
//       audiourls[oldCategory].splice(index, 1);
//       if (audiourls[oldCategory].length === 0) {
//         delete audiourls[oldCategory];
//       }

//       // Add song to new category
//       if (!audiourls[category]) {
//         audiourls[category] = [];
//       }
//       audiourls[category].push({ Name: name, url: url });

//       currentEdit = null; // Clear current edit
//     } else {
//       // Add new song
//       if (!audiourls[category]) {
//         audiourls[category] = [];
//       }
//       audiourls[category].push({ Name: name, url: url });
//     }

//     renderTable();

//     // Clear input fields
//     document.getElementById('category').value = '';
//     document.getElementById('name').value = '';
//     document.getElementById('url').value = '';

//     // Hide edit form
//     document.getElementById('editFormContainer').style.display = 'none';
//   } else {
//     alert("Please fill in all fields.");
//   }
// });

// document.getElementById('closeEditForm').addEventListener('click', function() {
//   // Clear the current edit if the form is closed without saving
//   currentEdit = null;
//   // Hide the edit form
//   document.getElementById('editFormContainer').style.display = 'none';
// });

// document.getElementById('addDataButton').addEventListener('click', function() {
//   // Clear the current edit when adding new data
//   currentEdit = null;
//   // Clear input fields
//   document.getElementById('category').value = '';
//   document.getElementById('name').value = '';
//   document.getElementById('url').value = '';
//   // Show the edit form
//   document.getElementById('editFormContainer').style.display = 'block';
// });

// renderTable();

// _("#saveChanges").on('click', function(){
//   var jsData = JSON.stringify(audiourls, null, 2)
//   Android.updateaudioUrl("var audiourls = " + jsData);
// })

var elt = function (tag) {
  return document.createElement(tag);
};

var currentEdit = null;
let currentTest = null;
var currentEditS = null;

function renderTable() {
  const tbody = document.getElementById("musicTable").querySelector("tbody");
  tbody.innerHTML = "";

  bus_data.forEach(function (category, index) {
    var from = category.from,
      to = category.to,
      stops = category.stops,
      ft = category.timings[0],
      tt = category.timings[1];

    const row = document.createElement("tr");
    const vendorCell = document.createElement("td");
    vendorCell.innerHTML = cheker("!Available", '', category.vendor

    );
    row.appendChild(vendorCell);
    const fromCell = document.createElement("td");
    fromCell.innerHTML = from;
    row.appendChild(fromCell);

    const toCell = document.createElement("td");
    toCell.innerHTML = to;
    row.appendChild(toCell);

    const stopsCell = document.createElement("td");
    stopsCell.innerHTML = "...";
    row.appendChild(stopsCell);

    const timingsCell = document.createElement("td");
    timingsCell.innerHTML = "...";
    row.appendChild(timingsCell);

    const routeCell = document.createElement("td");
    routeCell.innerHTML = cheker("!Available", undefined, category.route);
    row.appendChild(routeCell);

    const depoCell = document.createElement("td");
    depoCell.innerHTML = category.handler;
    row.appendChild(depoCell);

    const actionsCell = document.createElement("td");
    const editIcon = document.createElement("span");
    editIcon.textContent = "✏️"; // Unicode for pencil
    editIcon.classList.add("icon");
    editIcon.addEventListener("click", () => {
      document.getElementById("editFormContainer").style.display = "block";
      currentEdit = null;
      editData(category, index);
    });

    const removeIcon = document.createElement("span");
    removeIcon.textContent = "❌"; // Unicode for cross
    removeIcon.classList.add("icon");
    removeIcon.addEventListener("click", () => {
      removeData(index);
      renderTable();
    });

    actionsCell.appendChild(editIcon);
    actionsCell.appendChild(removeIcon);
    actionsCell.classList.add("actions");
    row.appendChild(actionsCell);

    tbody.appendChild(row);
  });
}
// tools
function normalizeTimeInput(time) {
  // Default to 8:00 am if no time is provided
  if (!time) return "08:00 am";

  // Add logic for single number inputs (e.g., "10" becomes "10:00")
  const singleHourMatch = time.match(/^(\d{1,2})$/);
  if (singleHourMatch) {
    time = `${singleHourMatch[1]}:00`;
  }

  // Regex to extract hours, minutes, and period if present
  const match = time.match(/(\d{1,2}):(\d{1,2})(?:\s*(am|pm))?/i);
  if (!match) return "08:00 am"; // Return a default valid time if parsing fails

  let [, hours, minutes, period] = match;
  hours = parseInt(hours, 10);
  minutes = parseInt(minutes, 10);

  // Format minutes with leading zero if needed
  minutes = String(minutes).padStart(2, "0");

  // Determine if the time is in the 24-hour format and convert if needed
  if (!period) {
    period = hours < 12 ? "am" : "pm";
    if (hours > 12) hours -= 12;
    else if (hours === 0) hours = 12; // Midnight case
  } else {
    period = period.toLowerCase();
  }

  // Ensure hours are formatted as two digits
  hours = String(hours).padStart(2, "0");

  return `${hours}:${minutes} ${period}`;
}

var capitalize = function (str) {
  return str
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ")
    .trim();
};

var cheker = function(replacer, finder, str){
  if (str === finder){
    return replacer
  } else {
    return str
  }
}

function addEditStops(stop, index) {
  const stpNElt = document.getElementById("stopName-sdsh"),
    timingsElt = document.getElementById("timing-sdsh"),
    distanceElt = document.getElementById("distnace-sdsh");

  // Reset form if editing a new stop
  if (currentEditS) {
    const { oldCategory } = currentEditS;
    stpNElt.value = oldCategory.name;
    timingsElt.value = `${oldCategory.timings[0]}, ${oldCategory.timings[1]}`;
    distanceElt.value = oldCategory.distance;
  } else {
    stpNElt.value = "";
    timingsElt.value = "";
    distanceElt.value = "";
  }

  currentTest = {
    fromV: document.querySelector(".yhg #from").value,
    toV: document.querySelector(".yhg #to").value,
    tiv: document.querySelector(".yhg #timing").value,
    vv: document.querySelector(".yhg #vendor").value,
    HV: document.querySelector(".yhg #depo").value,
    RV: document.querySelector(".yhg #route").value,
  };

  // Remove existing event listener to avoid duplicates
  document
    .getElementById("addsdBTN")
    .replaceWith(document.getElementById("addsdBTN").cloneNode(true));

  document.getElementById("addsdBTN").addEventListener("click", function (e) {
    e.preventDefault();

    currentEdit.stopsArr[index] = {};
    if (currentEditS) {
      currentEdit.stopsArr[index].name = stpNElt.value;
      currentEdit.stopsArr[index].timings = timingsElt.value
        .split(",")
        .map((time) => normalizeTimeInput(time.trim()));
      currentEdit.stopsArr[index].distance = distanceElt.value;
    } else {
      const category = currentEdit.oldCategory;
      const stops = category.stops;

      currentEdit.stopsArr.push({
        name: stpNElt.value,
        timings: timingsElt.value
          .split(",")
          .map((time) => normalizeTimeInput(time.trim())),
        distance: distanceElt.value,
      });
    }

    currentEditS = null;
    _("#addsdata").hide();
    editData(currentEdit.oldCategory, currentEdit.index);
  });

  _("#addsdata").show();
}

function removeStop(bus, index) {
  currentEdit.stopsArr = []

  console.log(currentEdit);
  
  editData(currentEdit.oldCategory, currentEdit.index);
}


function editData(bus, index) {
  var data = bus_data[index];
  var from = data.from,
    to = data.to,
    ft = data.timings[0],
    tt = data.timings[1],
    stops = data.stops,
    vendor = data.vendor,
    handler = data.handler,
    route = data.route;

  var stopsArr = [];

  var fromV = document.querySelector(".yhg #from");
  fromV.value = from;
  var toV = document.querySelector(".yhg #to");
  toV.value = to;
  var TIV = document.querySelector(".yhg #timing");
  TIV.value = ft + ", " + tt;
  var VV = document.querySelector(".yhg #vendor");
  VV.value = vendor;
  var HV = document.querySelector(".yhg #depo");
  HV.value = handler;
  var RV = document.querySelector(".yhg #route");
  RV.value = route;
  var parent = _(".dropdownlists").html("");

  stops.forEach(function (stop) {
    stopsArr.push(stop);
  });

  if (currentEdit && currentTest) {
    stopsArr = currentEdit.stopsArr;

    fromV.value = currentTest.fromV;
    toV.value = currentTest.toV;
    TIV.value = currentTest.tiv;
    VV.value = currentTest.vv;
    HV.value = currentTest.HV;
    RV.value = currentTest.RV;
    currentTest = null;
  }

  stopsArr.forEach(function (stop, index) {
    var main = _("<div>")
      .addClass("shsd-every")
      .append(_("<div>").html(`Name:- <span>${stop.name}</span>`))
      .append(_("<br>"))
      .append(_("<div>").html(`Arrival:- <span>${stop.timings[0]}</span>`))
      .append(_("<br>"))
      .append(_("<div>").html(`Departure:- <span>${stop.timings[1]}</span>`))
      .append(_("<br>"))
      .append(
        _("<div>")
          .addClass("actions-sdshe")
          .append(
            _("<span>")
              .append(_("<i>").addClass("yhgi yhgi-pencil-24"))
              .on("click", function () {
                currentEditS = { oldCategory: stop, index };
                addEditStops(stop, index);
              })
          )
          .append(
            _("<span>")
              .append(_("<i>").addClass("yhgi yhgi-trash-24"))
              .on("click", function () {
                removeStop(stop, index);
              })
          )
      );

    parent.append(main);
  });

  document
    .querySelector(".stops-handler-main .shssi button")
    .addEventListener("click", function (e) {
      e.preventDefault();
      addEditStops();
    });

  _("#closeEditForm").on("click", function () {
    _(this).parent().parent().hide();
    window[_(this).attr("currentType")] = null;
  });

  _("#pushDataButton").on("click", function () {
    data.vendor = capitalize(VV.value);
    data.from = capitalize(fromV.value);
    data.to = capitalize(toV.value);
    data.stops = stopsArr;
    data.timings = TIV.value
      .split(",")
      .map((time) => normalizeTimeInput(time.trim()));
    data.route = capitalize(RV.value);
    data.handler = capitalize(HV.value);

    document.getElementById("editFormContainer").style.display = "none";
    renderTable();
  });

  currentEdit = {
    oldCategory: bus,
    index,
    stopsArr: stopsArr,
  };
}

var removeData = function (index) {
  delete bus_data[index];
};

renderTable();
